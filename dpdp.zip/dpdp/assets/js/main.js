 
 $(window).scroll(function() {
    var scroll = $(window).scrollTop();
    if (scroll >= 40) {
        $(".header_main").addClass("header-fixed");
    } else {
        $(".header_main").removeClass("header-fixed");
    }
});  


$(document).ready(function() {
    var swiper = new Swiper('.testimonial-swiper', {
            loop: true,
            pagination: {
                el: '.swiper-pagination',
                clickable: true,
                renderBullet: function (index, className) {
                    var thumb = document.querySelectorAll('.swiper-slide')[index].getAttribute('data-bullet-thumb');
                    return '<span class="' + className + '" style="background-image:url(' + thumb + ')"></span>';
                },
            },
            effect: 'fade',
            fadeEffect: {
                crossFade: true
            }
        });
    });


    $('.dropdownicon .menu_link').click(function(e) {
        var active=$(this).parent().hasClass('active');
        $('.mobilemenus_box').removeClass('active');
        if(active){
    
        }else{
            $(this).parent().addClass('active');
        
        }
    }); 


       // FAQ 
       $('.faq_box_head').click(function(e) {
        $('.faq_box').removeClass('active');
        $(this).parent().addClass('active');
    }); 
// FAQ 